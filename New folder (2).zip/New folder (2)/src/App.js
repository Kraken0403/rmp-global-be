import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
import About from './pages/About';
import Contact from './pages/Contact';
import Blogs from './pages/Blogs';
import BlogInner from './pages/BlogInner';
import VirtualCFO from './pages/VirtualCFO';
import TaxCompliance from './pages/TaxCompliance';
import Misservices from './pages/Misservices';
import Financial from './pages/Financial';
import VirtualCFOService from './pages/VirtualCFOService';
import DataLabellingService from './pages/DataLabellingService';
import DataAnalyticsService from './pages/DataAnalyticsService';
import BookKeeping from './pages/Bookkeeping';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route exact path="/" element={<Home/>} />
          <Route exact path="/about-us" element={<About/>}/>
          <Route exact path="/contact-us" element={<Contact/>}/>
          <Route exact path="/blogs" element={<Blogs/>}/>
          <Route exact path="/virtual-cfo" element={<VirtualCFO/>}/>
          <Route exact path="/tax-compliance" element={<TaxCompliance/>}/>
          <Route exact path="/blogs/:id" element={<BlogInner/>}/>
          <Route exact path="/mis-services" element={<Misservices/>}/>
          <Route exact path="/financial" element={<Financial/>}/>
          <Route exact path="/virtual-CFO-service" element={<VirtualCFOService/>}/>
          <Route exact path="/dataLablling-service" element={<DataLabellingService/>}/>
          <Route exact path="/dataanalytics-service" element={<DataAnalyticsService/>}/>
          <Route exact path="/book-keeping" element={<BookKeeping/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
